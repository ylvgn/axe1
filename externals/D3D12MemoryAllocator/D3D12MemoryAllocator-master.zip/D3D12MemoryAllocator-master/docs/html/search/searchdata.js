var indexSectionsWithContent =
{
  0: "abcdefghijlmnopqrstuvw",
  1: "abcdpstv",
  2: "d",
  3: "d",
  4: "abcefgis",
  5: "abcefhlmnoprstu",
  6: "af",
  7: "adpv",
  8: "adpv",
  9: "cd",
  10: "d",
  11: "abcdfghijlmnopqrstuvw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "related",
  10: "defines",
  11: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerations",
  8: "Enumerator",
  9: "Friends",
  10: "Macros",
  11: "Pages"
};

